LRC PHASE 4 — READ-ONLY EVIDENCE HANDOFF

Purpose:
Supply the original V5 package, owner records, model/build/run metadata,
exceptions, correction sources, comparison sources, logs, and audit reports
for a bounded provenance and requirements-traceability review.

This handoff is a copy. It does not authorize experiments.

Preservation:
- Original project files were copied; source files were not patched.
- The frozen V5 package is included.
- Failed original assessment/comparator evidence is retained where present.
- No MATLAB or Simulink execution was performed by this packaging script.
- The large native/raw .mat files are not embedded in this compact archive.
  Their sizes and SHA-256 values are recorded in RUN_DATA_SHA256_INVENTORY.json.
- A data hash in that inventory is not independent verification of a file
  until the file's bytes are made available to the reviewing workspace.

Required review:
- Compare the frozen assessor with the recovered assessor and runtime overlay.
- Compare the original convergence/fresh comparators with the replacements.
- Specifically review the deliberate change from nominal+stress convergence
  to nominal-only convergence.
- Verify numerical formulas, criteria, scenario scope, missing-data handling,
  and PASS/FAIL logic before granting independent credit.
- Keep nominal validation distinct from overall project acceptance.

Current boundaries:
- No new simulation, construction, tuning, stress test, or deployment approval.
- Historical source continuity remains disclosed as unresolved.
