auditDir = getenv('FRESHAUDIT');
packageDir = getenv('PKG');
outDir = getenv('OUT');
ownerFile = getenv('OWNER');
convergenceFile = getenv('CONVERGENCE');

assert(~isempty(auditDir) && ~isempty(packageDir) ...
    && ~isempty(outDir) && ~isempty(ownerFile) ...
    && ~isempty(convergenceFile),'Required environment variable missing.');

addpath(fullfile(packageDir,'matlab'));
addpath(auditDir,'-begin');

compare_fresh_saved_data(outDir,ownerFile,convergenceFile,auditDir);
