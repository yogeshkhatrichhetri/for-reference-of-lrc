function compare_fresh_saved_data(out,approval,convergenceFile,auditDir)
% Read-only comparison of existing refined and fresh nominal run data.
% Does not call sim(), rebuild, or save the Simulink model.

[~,owner] = p4_guard(approval,'simulation',out);

refinedDir = fullfile(out,'nominal_refined');
freshDir = fullfile(out,'nominal_fresh');

refinedRawFile = fullfile(refinedDir,'raw_timeseries.mat');
freshRawFile = fullfile(freshDir,'raw_timeseries.mat');

refinedAssessmentFile = fullfile(refinedDir,'assessment.json');
freshAssessmentFile = fullfile(freshDir,'assessment.json');

refinedCompletionFile = fullfile(refinedDir,'completion.json');
freshCompletionFile = fullfile(freshDir,'completion.json');

resultFile = fullfile(auditDir,'fresh_comparison_recovered.json');

assert(isfile(refinedRawFile),'Refined raw data missing.');
assert(isfile(freshRawFile),'Fresh raw data missing.');
assert(isfile(refinedAssessmentFile),'Refined assessment missing.');
assert(isfile(freshAssessmentFile),'Fresh assessment missing.');
assert(isfile(refinedCompletionFile),'Refined completion record missing.');
assert(isfile(freshCompletionFile),'Fresh completion record missing.');
assert(isfile(convergenceFile),'Nominal convergence record missing.');
assert(~isfile(resultFile),'Refusing to overwrite comparison evidence.');

convergence = jsondecode(fileread(convergenceFile));
assert(convergence.all_checks_pass, ...
    'Nominal convergence prerequisite did not pass.');

refinedAssessment = jsondecode(fileread(refinedAssessmentFile));
freshAssessment = jsondecode(fileread(freshAssessmentFile));
refinedCompletion = jsondecode(fileread(refinedCompletionFile));
freshCompletion = jsondecode(fileread(freshCompletionFile));

assert(refinedAssessment.all_checks_pass, ...
    'Refined numerical assessment failed.');
assert(freshAssessment.all_checks_pass, ...
    'Fresh numerical assessment failed.');
assert(refinedCompletion.completed && refinedCompletion.numerical_checks_pass, ...
    'Refined completion prerequisite failed.');
assert(freshCompletion.completed && freshCompletion.numerical_checks_pass, ...
    'Fresh completion prerequisite failed.');

a = load(refinedRawFile,'raw');
b = load(freshRawFile,'raw');

rows = struct('name',{},'value',{},'limit',{},'pass',{},'note',{});
tags = {'CE','CN','DE','DN'};
signals = {'y','raw','applied'};

for k = 1:numel(tags)
    for j = 1:numel(signals)
        tag = tags{k};
        signal = signals{j};
        key = [tag '_' signal];

        sa = a.raw.(key);
        sb = b.raw.(key);

        ta = sa.Time(:);
        va = reshape(sa.Data,[],1);
        tb = sb.Time(:);
        vb = reshape(sb.Data,[],1);

        % Match the preregistered procedure: remove duplicate event
        % timestamps using the last value, then require identical grids.
        [ta,ia] = unique(ta,'last');
        va = va(ia);
        [tb,ib] = unique(tb,'last');
        vb = vb(ib);

        gridEqual = isequal(ta,tb) ...
            && numel(va)==numel(ta) ...
            && numel(vb)==numel(tb);

        add([key '_timestamp_grid_identical'], ...
            double(~gridEqual),0,'0 means grids are identical.');

        if ~gridEqual
            % Do not interpolate or compare samples on mismatched grids.
            add([key '_max_abs_difference_V'],NaN,1e-9, ...
                'NOT COMPUTED: timestamp grids differ; no interpolation used.',false);
            continue
        end

        if isempty(va) || any(~isfinite(va)) || any(~isfinite(vb)) ...
                || ~isreal(va) || ~isreal(vb)
            add([key '_max_abs_difference_V'],NaN,1e-9, ...
                'FAIL: empty, nonfinite, or nonreal data.',false);
            continue
        end

        delta = max(abs(va-vb));

        add([key '_max_abs_difference_V'],delta,1e-9, ...
            'Maximum absolute difference on identical timestamps.');
    end
end

allPass = all([rows.pass]);

result = struct( ...
    'status','FRESH_PROCESS_REPRODUCIBILITY_COMPARISON_NOT_PROJECT_ACCEPTANCE', ...
    'created_utc',char(datetime('now','TimeZone','UTC', ...
        'Format',"yyyy-MM-dd'T'HH:mm:ss'Z'")), ...
    'comparison','nominal_refined versus nominal_fresh', ...
    'supplemental_stress_run',false, ...
    'original_package_modified',false, ...
    'refined_assessment_pass',refinedAssessment.all_checks_pass, ...
    'fresh_assessment_pass',freshAssessment.all_checks_pass, ...
    'convergence_prerequisite_pass',convergence.all_checks_pass, ...
    'all_checks_pass',allPass, ...
    'approval_record_sha256',p4_hash(approval), ...
    'convergence_record_sha256',p4_hash(convergenceFile), ...
    'refined_raw_sha256',p4_hash(refinedRawFile), ...
    'fresh_raw_sha256',p4_hash(freshRawFile), ...
    'refined_assessment_sha256',p4_hash(refinedAssessmentFile), ...
    'fresh_assessment_sha256',p4_hash(freshAssessmentFile), ...
    'checks',rows);

fid = fopen(resultFile,'w');
assert(fid>=0,'Cannot create fresh comparison record.');
cleanup = onCleanup(@() fclose(fid));
fwrite(fid,jsonencode(result,'PrettyPrint',true),'char');
clear cleanup

fprintf('\n========== FRESH-PROCESS COMPARISON ==========\n');
fprintf('Checks passed: %d of %d\n',sum([rows.pass]),numel(rows));
fprintf('ALL FRESH COMPARISON CHECKS PASS: %d\n',allPass);

for k = 1:numel(rows)
    if rows(k).pass
        verdict = 'PASS';
    else
        verdict = 'FAIL';
    end

    fprintf('%s | value=%.17g | limit=%.17g | %s | %s\n', ...
        rows(k).name,rows(k).value,rows(k).limit, ...
        verdict,rows(k).note);
end

fprintf('\nSaved record: %s\n',resultFile);
fprintf('This is not overall project acceptance.\n');

    function add(name,value,limit,note,forcedPass)
        if nargin < 5
            forcedPass = isfinite(value) && value<=limit;
        end

        rows(end+1) = struct( ...
            'name',name, ...
            'value',value, ...
            'limit',limit, ...
            'pass',logical(forcedPass), ...
            'note',note); %#ok<AGROW>
    end
end
