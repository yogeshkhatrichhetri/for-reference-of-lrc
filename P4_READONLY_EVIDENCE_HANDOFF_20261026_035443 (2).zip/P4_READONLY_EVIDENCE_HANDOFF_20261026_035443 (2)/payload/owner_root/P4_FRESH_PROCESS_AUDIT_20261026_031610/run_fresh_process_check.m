packageDir = getenv('PKG');
outDir = getenv('OUT');
ownerFile = getenv('OWNER');
overlayDir = getenv('OVERLAY');

assert(~isempty(packageDir) && ~isempty(outDir) ...
    && ~isempty(ownerFile) && ~isempty(overlayDir), ...
    'Required environment variables are missing.');

addpath(fullfile(packageDir,'matlab'));
addpath(overlayDir,'-begin');

expectedAssessor = fullfile(overlayDir,'p4_assess.m');
actualAssessor = which('p4_assess');

fprintf('Active assessor: %s\n',actualAssessor);
assert(strcmp(actualAssessor,expectedAssessor), ...
    'Corrected assessor overlay is not active.');

assert(isempty(find_system('type','block_diagram')), ...
    'Fresh MATLAB process required; a block diagram is already loaded.');

fprintf('Starting authorized nominal fresh-process check...\n');

% Loads the saved model, runs nominal/fresh, and performs the
% package's fresh-versus-refined post-processing comparison.
phase4_reopen(outDir,ownerFile);
