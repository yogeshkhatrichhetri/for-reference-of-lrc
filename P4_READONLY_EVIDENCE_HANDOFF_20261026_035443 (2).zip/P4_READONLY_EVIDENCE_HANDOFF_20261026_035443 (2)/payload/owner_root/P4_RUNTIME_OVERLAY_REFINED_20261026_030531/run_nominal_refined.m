overlayDir = getenv('OVERLAY');
packageDir = getenv('PKG');
outDir = getenv('OUT');
ownerFile = getenv('OWNER');

assert(~isempty(overlayDir), 'OVERLAY environment variable missing.');
assert(~isempty(packageDir), 'PKG environment variable missing.');
assert(~isempty(outDir), 'OUT environment variable missing.');
assert(~isempty(ownerFile), 'OWNER environment variable missing.');

addpath(fullfile(packageDir, 'matlab'));
addpath(overlayDir, '-begin');

expectedAssessor = fullfile(overlayDir, 'p4_assess.m');
actualAssessor = which('p4_assess');

fprintf('Resolved assessor: %s\n', actualAssessor);
assert(strcmp(actualAssessor, expectedAssessor), ...
    'Runtime overlay is not the active p4_assess implementation.');

fprintf('V5 package path: %s\n', packageDir);
fprintf('Run directory: %s\n', fullfile(outDir, 'nominal_refined'));
fprintf('Starting nominal refined-resolution experiment...\n');

phase4_run(outDir, ownerFile, 'nominal', 'refined');
