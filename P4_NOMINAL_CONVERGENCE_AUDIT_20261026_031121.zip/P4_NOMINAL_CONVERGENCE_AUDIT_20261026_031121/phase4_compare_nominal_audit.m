function phase4_compare_nominal_audit(out,approval,baseReportPath,auditDir)
% Post-process existing nominal runs only. Does not call sim().
% This is an isolated comparator; the frozen package is not modified.

[pkg,owner] = p4_guard(approval,'simulation',out); %#ok<ASGLU>

baseDir = fullfile(out,'nominal_base');
refinedDir = fullfile(out,'nominal_refined');

baseRawFile = fullfile(baseDir,'raw_timeseries.mat');
refinedRawFile = fullfile(refinedDir,'raw_timeseries.mat');
refinedAssessmentFile = fullfile(refinedDir,'assessment.json');
refinedCompletionFile = fullfile(refinedDir,'completion.json');

outFile = fullfile(auditDir,'nominal_convergence_comparison.json');

assert(isfile(baseRawFile),'Base raw data missing.');
assert(isfile(refinedRawFile),'Refined raw data missing.');
assert(isfile(baseReportPath),'Recovered base assessment missing.');
assert(isfile(refinedAssessmentFile),'Refined assessment JSON missing.');
assert(isfile(refinedCompletionFile),'Refined completion record missing.');
assert(~isfile(outFile),'Refusing to overwrite comparison evidence.');

baseLoaded = load(baseRawFile,'raw');
refinedLoaded = load(refinedRawFile,'raw');

baseReportLoaded = load(baseReportPath,'report');
ar = baseReportLoaded.report;
br = jsondecode(fileread(refinedAssessmentFile));
completion = jsondecode(fileread(refinedCompletionFile));

assert(isfield(ar,'all_checks_pass'),'Base assessment lacks check summary.');
assert(isfield(br,'all_checks_pass'),'Refined assessment lacks check summary.');

rows = struct('name',{},'value',{},'limit',{},'pass',{});
tags = {'CE','CN','DE','DN'};
signals = {'y','raw','applied'};

% Compare saved base and refined trajectories without new simulations.
for k = 1:numel(tags)
    tag = tags{k};

    for j = 1:numel(signals)
        signal = signals{j};
        key = [tag '_' signal];

        sa = baseLoaded.raw.(key);
        sb = refinedLoaded.raw.(key);

        [ta,ia] = unique(sa.Time(:),'last');
        va = sa.Data(:);
        va = va(ia);

        [tb,ib] = unique(sb.Time(:),'last');
        vb = sb.Data(:);
        vb = vb(ib);

        % Retain the preregistered comparison convention.
        method = 'linear';
        if startsWith(tag,'D') && ~strcmp(signal,'y')
            method = 'previous';
        end

        assert(ta(1) >= tb(1) && ta(end) <= tb(end), ...
            'Time coverage mismatch for %s.',key);

        delta = max(abs(va-interp1(tb,vb,ta,method)));

        limit = 1e-4;
        if strcmp(signal,'y')
            limit = 1e-7;
        end

        add([key '_base_refined_difference'],delta,limit);
    end

    % Compare upper-bound metrics using the approved limits.
    am = ar.(tag).metrics;
    bm = br.(tag).metrics;

    peakDelta = abs(am.peak_upper_bound_V-bm.peak_upper_bound_V);
    settleDelta = abs(am.settling_time_conservative_upper_s ...
        - bm.settling_time_conservative_upper_s);

    add([tag '_peak_convergence'],peakDelta,1e-7);
    add([tag '_settling_convergence'],settleDelta,3e-6);

    add([tag '_strict_settling_with_uncertainty'], ...
        bm.settling_time_conservative_upper_s+settleDelta, ...
        0.05-eps(0.05));

    add([tag '_strict_peak_with_uncertainty'], ...
        bm.peak_upper_bound_V+peakDelta, ...
        1.5606-eps(1.5606));
end

% Numerical assessments for both runs are prerequisites.
bothRunsPass = islogical(ar.all_checks_pass) ...
    && isscalar(ar.all_checks_pass) ...
    && ar.all_checks_pass ...
    && islogical(br.all_checks_pass) ...
    && isscalar(br.all_checks_pass) ...
    && br.all_checks_pass ...
    && isfield(completion,'completed') ...
    && completion.completed ...
    && completion.numerical_checks_pass;

add('both_run_assessments_pass',double(~bothRunsPass),0);

allPass = all([rows.pass]);

result = struct( ...
    'status','NOMINAL_ONLY_CONVERGENCE_COMPARISON_NOT_PROJECT_ACCEPTANCE', ...
    'created_utc',char(datetime('now','TimeZone','UTC', ...
        'Format',"yyyy-MM-dd'T'HH:mm:ss'Z'")), ...
    'scenario','nominal only', ...
    'supplemental_stress_run',false, ...
    'original_package_modified',false, ...
    'base_assessment_pass',ar.all_checks_pass, ...
    'refined_assessment_pass',br.all_checks_pass, ...
    'all_checks_pass',allPass, ...
    'approval_record_sha256',p4_hash(approval), ...
    'base_raw_sha256',p4_hash(baseRawFile), ...
    'refined_raw_sha256',p4_hash(refinedRawFile), ...
    'base_report_sha256',p4_hash(baseReportPath), ...
    'refined_assessment_sha256',p4_hash(refinedAssessmentFile), ...
    'checks',rows);

fid = fopen(outFile,'x');
assert(fid >= 0,'Unable to create new comparison record.');
cleanup = onCleanup(@() fclose(fid));
fwrite(fid,jsonencode(result,'PrettyPrint',true),'char');
clear cleanup

fprintf('\n========== NOMINAL CONVERGENCE RESULTS ==========\n');
fprintf('Base run checks passed:    %d\n',ar.all_checks_pass);
fprintf('Refined run checks passed: %d\n',br.all_checks_pass);
fprintf('Convergence checks passed: %d of %d\n', ...
    sum([rows.pass]),numel(rows));
fprintf('ALL CONVERGENCE CHECKS PASS: %d\n',allPass);

for k = 1:numel(rows)
    fprintf('%s | value=%.17g | limit=%.17g | %s\n', ...
        rows(k).name,rows(k).value,rows(k).limit, ...
        string(rows(k).pass*"PASS" + (~rows(k).pass)*"FAIL"));
end

fprintf('\nComparison evidence: %s\n',outFile);
fprintf('This is not overall project acceptance.\n');

    function add(name,value,limit)
        rows(end+1) = struct( ...
            'name',name, ...
            'value',value, ...
            'limit',limit, ...
            'pass',isfinite(value) && value <= limit); %#ok<AGROW>
    end
end
