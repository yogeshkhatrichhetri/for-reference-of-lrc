auditDir = getenv('AUDIT');
packageDir = getenv('PKG');
outDir = getenv('OUT');
ownerFile = getenv('OWNER');
baseReportPath = getenv('BASE_REPORT');

assert(~isempty(auditDir) && ~isempty(packageDir) ...
    && ~isempty(outDir) && ~isempty(ownerFile) ...
    && ~isempty(baseReportPath),'Missing environment variable.');

addpath(fullfile(packageDir,'matlab'));
addpath(auditDir,'-begin');

phase4_compare_nominal_audit( ...
    outDir,ownerFile,baseReportPath,auditDir);
