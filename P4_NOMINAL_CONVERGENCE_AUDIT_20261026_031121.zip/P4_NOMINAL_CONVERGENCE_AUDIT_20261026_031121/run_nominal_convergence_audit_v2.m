auditDir = getenv('AUDIT');
packageDir = getenv('PKG');
outDir = getenv('OUT');
ownerFile = getenv('OWNER');
baseReportPath = getenv('BASE_REPORT');

assert(~isempty(auditDir) && ~isempty(packageDir) ...
    && ~isempty(outDir) && ~isempty(ownerFile) ...
    && ~isempty(baseReportPath),'Required environment variable missing.');

addpath(fullfile(packageDir,'matlab'));
addpath(auditDir,'-begin');

phase4_compare_nominal_audit_v2( ...
    outDir,ownerFile,baseReportPath,auditDir);
