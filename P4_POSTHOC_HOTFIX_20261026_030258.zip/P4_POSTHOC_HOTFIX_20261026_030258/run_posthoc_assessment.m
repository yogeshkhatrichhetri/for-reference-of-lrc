hotfixDir = getenv('HOTFIX');
packageDir = getenv('PKG');
runDir = getenv('RUN');

assert(~isempty(hotfixDir), 'HOTFIX environment variable missing.');
assert(~isempty(packageDir), 'PKG environment variable missing.');
assert(~isempty(runDir), 'RUN environment variable missing.');

rawFile = fullfile(runDir, 'raw_timeseries.mat');
summaryFile = fullfile(hotfixDir, 'posthoc_assessment_summary.txt');
reportFile = fullfile(hotfixDir, 'posthoc_assessment.mat');

assert(isfile(rawFile), 'Saved raw time-series file is missing.');
assert(isfile(fullfile(hotfixDir, 'p4_assess_hotfix.m')), ...
    'Isolated assessor hotfix is missing.');
assert(~isfile(summaryFile), 'Summary already exists; refusing overwrite.');
assert(~isfile(reportFile), 'Report already exists; refusing overwrite.');

addpath(fullfile(packageDir, 'matlab'));
addpath(hotfixDir, '-begin');

fprintf('Loading existing nominal raw data...\n');
loaded = load(rawFile, 'raw');

fprintf('Running post-hoc numerical assessment only...\n');
report = p4_assess_hotfix(loaded.raw, 'nominal', 2e-6);

save(reportFile, 'report', '-v7.3');

fid = fopen(summaryFile, 'w');
assert(fid >= 0, 'Cannot create assessment summary.');

fprintf(fid, 'all_checks_pass=%d\n', report.all_checks_pass);
fprintf(fid, 'status=%s\n', report.status);

for k = 1:numel(report.checks)
    c = report.checks(k);
    fprintf(fid, '%s\tvalue=%.17g\tlimit=%.17g\tstrict=%d\tpass=%d\n', ...
        c.name, c.value, c.limit, c.strict, c.pass);
end

fclose(fid);

fprintf('\n========== ASSESSMENT SUMMARY ==========\n');
disp(fileread(summaryFile));
fprintf('Assessment report saved to: %s\n', reportFile);
fprintf('This is post-processing of existing data, not project acceptance.\n');
